const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
app.use(express.json()); // Para parsear JSON
app.use(cors()); // Habilitar CORS

const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI;

// Conectar ao MongoDB
mongoose.connect(MONGO_URI)
    .then(() => console.log("Conectado ao MongoDB!"))
    .catch((err) => console.error("Erro de conexão ao MongoDB: ", err));

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
